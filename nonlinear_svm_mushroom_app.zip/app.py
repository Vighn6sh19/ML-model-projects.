from flask import Flask, render_template, request
import pandas as pd
import joblib
import json
import os

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_PATH = os.path.join(BASE_DIR, "nonlinear_svm_mushroom.pkl")
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.json")

if not os.path.exists(MODEL_PATH) or not os.path.exists(SCHEMA_PATH):
    raise FileNotFoundError(
        "Model/schema files are missing. Extract the complete project ZIP first."
    )

model = joblib.load(MODEL_PATH)
with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
    schema = json.load(f)

FEATURES = schema["features"]
OPTIONS = schema["options"]
LABELS = schema["labels"]

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = None
    error = None
    selected = {feature: OPTIONS[feature][0] for feature in FEATURES}

    if request.method == "POST":
        try:
            row = {}
            for feature in FEATURES:
                value = request.form.get(feature, "")
                if value not in OPTIONS[feature]:
                    raise ValueError("Invalid value supplied.")
                row[feature] = value
            selected = row

            sample = pd.DataFrame([row], columns=FEATURES)
            predicted_class = str(model.predict(sample)[0])
            prediction = LABELS.get(predicted_class, predicted_class)
        except (ValueError, KeyError):
            error = "Please choose a valid value for every mushroom feature."

    return render_template(
        "index.html",
        features=FEATURES,
        options=OPTIONS,
        selected=selected,
        prediction=prediction,
        error=error
    )

if __name__ == "__main__":
    app.run(debug=True)

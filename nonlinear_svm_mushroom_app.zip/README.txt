NON-LINEAR SVM MUSHROOM CLASSIFICATION APP

This project uses the uploaded mushrooms.csv dataset (8124 rows, 22 categorical input features).
The target labels in the dataset are:
- e = edible
- p = poisonous

Files:
- app.py: Flask web application
- templates/index.html: form with dropdowns for all 22 features
- nonlinear_svm_mushroom.pkl: trained RBF-kernel SVM pipeline (includes one-hot encoding)
- schema.json: feature names and valid dropdown options
- requirements.txt: required packages

Run:
1. Extract the ZIP.
2. Open a terminal in the extracted project folder.
3. Install dependencies:
   pip install -r requirements.txt
4. Start the app:
   python app.py
5. Open http://127.0.0.1:5000/

Held-out test accuracy during training: 100.00% (80/20 split, random_state=42).
The model was trained from the provided CSV. Do not use the prediction to determine whether a real mushroom is safe to eat.
